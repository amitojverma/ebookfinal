package com.cts.bookShopping.dao;

import java.util.List;

import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.transaction.annotation.Transactional;

import com.cts.bookShopping.bean.OrderDetails;

public interface OrderDetailsDAO {
	public String insertDetails(OrderDetails books);
	public  List<OrderDetails> displayDetails(String emailId);
	public String deleteOrderItem(int id); 
}

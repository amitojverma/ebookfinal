package com.cts.bookShopping.controller;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.SessionAttribute;
import org.springframework.web.bind.annotation.SessionAttributes;
import org.springframework.web.servlet.ModelAndView;

import com.cts.bookShopping.bean.AddToCart;
import com.cts.bookShopping.bean.Books;
import com.cts.bookShopping.bean.Category;
import com.cts.bookShopping.bean.OrderDetails;
import com.cts.bookShopping.bean.userRegistration;
import com.cts.bookShopping.service.AddToCartService;
import com.cts.bookShopping.service.BooksService;
import com.cts.bookShopping.service.CategoryService;
import com.cts.bookShopping.service.OrderDetailsService;


@Controller
/*@SessionAttributes("books")*/
public class BooksController {
	 public List<Books> li = new ArrayList<Books>();
	@Autowired
	BooksService booksService;
	@Autowired
	AddToCartService addToCartService;
	@Autowired
	CategoryService categoryService;
	@Autowired
	OrderDetailsService orderDetailsService;
	
	@RequestMapping("adminHomepage.html")
	public String getBooks(){
		return "adminHomepage";
	}
	@RequestMapping("home.html")
	 public ModelAndView Home(){
		ModelAndView mav = new ModelAndView();
		List<Books> list = booksService.getAllBook();
		mav.addObject("books",list);
		mav.setViewName("home");
		return mav;
	}
	@RequestMapping(value="booksadded.html",method = RequestMethod.POST)
	public String addBook(@ModelAttribute Books books,HttpSession httpSession,HttpServletRequest httpServletRequest){
		
		ModelAndView modelAndView = new ModelAndView();
		//Books books=(Books)httpSession.getAttribute("books");
		System.out.println("hiiiiiiiiiii");
		books.catName = httpServletRequest.getParameter("catName");
		if("true".equals(booksService.insertBook(books)))
		{
			booksService.insertBook(books);
			System.out.println(books);
			return "addproduct";
		}
		else
		{
			return null;
		}
		
	}
	@GetMapping(value="addproduct.html")
	public ModelAndView viewCategory(@ModelAttribute Category category,HttpSession httpSession){
		ModelAndView modelAndView = new ModelAndView();
		
		List<Category> list = categoryService.getAllCategory();
		System.out.println(list);
		modelAndView.addObject("category", list);
		modelAndView.setViewName("addproduct");
		return modelAndView;
	}
	@GetMapping(value="viewBook.html")
	public ModelAndView getViewProduct(@RequestParam("id") String id,HttpSession httpSession){
		ModelAndView mav = new ModelAndView();
		
		Books books= booksService.getBookById(id);
		httpSession.setAttribute("books", books);
		System.out.println(books);
		mav.addObject("book",books);
		return mav;
	}
	/*@GetMapping(value="addToCart.html")
	public ModelAndView addToCartdisp(){
		ModelAndView mav = new ModelAndView();
		mav.setViewName("addToCart");
		return mav;
	}*/
	@PostMapping(value="home.html")
	public ModelAndView addToCart(@RequestParam("bookID") String id,@ModelAttribute AddToCart addToCart,HttpSession session){
		ModelAndView mav = new ModelAndView();
		String user;
		//String id1 = (String)session.getAttribute("bookID");
		System.out.println("BookID"+id);
		user = (String) session.getAttribute("userId");
		System.out.println(user);
		Books books= booksService.getBookById(id);
		/*if("true".equals(addToCartService.addCartDetails(new AddToCart(1,books.getBookName(),user,books.getPrice())))){*/
			addToCartService.addCartDetails(new AddToCart(1,books.getBookName(),user,books.getPrice()));
			System.out.println("Addto Cart Success");
			List<Books> list = booksService.getAllBook();
			mav.addObject("books",list);
			mav.setViewName("home");
			
		/*}
		else
			System.out.println("Addto Cart Fail");*/
		return mav;
	}
	@RequestMapping(value="viewCart.html")
	public ModelAndView viewCart(/*@RequestParam("id") String id,*/HttpSession session){
		ModelAndView mav = new ModelAndView();
		String user = (String) session.getAttribute("userId");

		System.out.println("This is: "+user);
		//Books books= booksService.getBookById(id);
		List<AddToCart> list = addToCartService.viewCartDetails(user);
		mav.addObject("list",list);
		String totalPrice = addToCartService.totalPrice(user);
		mav.addObject("totalPrice", totalPrice);
		mav.setViewName("addToCart");
		return mav;
	}
	@RequestMapping(value="addToCart.html")
	public ModelAndView removeItemFromCart(@ModelAttribute AddToCart addToCart ,@RequestParam("id") int id,HttpSession session){
		ModelAndView mav = new ModelAndView();
			addToCartService.deleteCartItem(id);
			System.out.println("Item Removed Successfully from Cart...");
			String user = (String) session.getAttribute("userId");
			 /*response.setIntHeader("Refresh", 1);*/
			System.out.println(user);
			List<AddToCart> list = addToCartService.viewCartDetails(user);
			mav.addObject("list",list);
			mav.setViewName("addToCart");
			return mav;
	}
	@RequestMapping("checkout.html")
	public String checkout(){
		return "checkout";
	}
	@RequestMapping("orderPlaced.html")
	public String orderStatus(){
		return "orderPlaced";
	}
	@GetMapping(value="editBook.html")
	public ModelAndView getDeleteProduct(){
		ModelAndView modelAndView = new ModelAndView();

		List<Books> list = booksService.getAllBook();
		System.out.println(list);
		modelAndView.addObject("books",list);
		
//		
	//	modelAndView.setViewName("deleteBook");
		return modelAndView;
	}
	@RequestMapping(value="editBook12.html")
	public ModelAndView getDeleteProduct(@RequestParam("id") String id,HttpSession httpSession){
		ModelAndView mav = new ModelAndView();
		String st = booksService.deleteBook(id);
		if("true".equals(st))
		{
			List<Books> list = booksService.getAllBook();
			System.out.println(list);
			mav.addObject("books",list);
				
			mav.setViewName("editBook");
			
			
		}
		return mav;
	}





@RequestMapping(value="search.html", method=RequestMethod.POST)
	public ModelAndView getViewBook(@RequestParam("search") String name,HttpSession httpSession){
		ModelAndView mav = new ModelAndView();
	Books book= booksService.getBookByName(name);
		if(book==null){
			List<Books> list=booksService.getAllBook();
			mav.addObject("books",list);
			mav.setViewName("home");
		}
		else{
		mav.addObject("books",book);
		mav.setViewName("search");
		}
		return mav;
	}

/*@RequestMapping("orderPlaced.html")
public String checkOut(){
	return "orderPlaced";
}*/
@RequestMapping(value="checkout.html",method = RequestMethod.POST)
public String addDetails(@ModelAttribute OrderDetails books,HttpSession session,HttpServletRequest httpServletRequest){
	
	ModelAndView modelAndView = new ModelAndView();
	
		String user = (String) session.getAttribute("userId");
		orderDetailsService.insertDetails(new OrderDetails(1, user,"ORD PLACED"));
		return "checkout";
}
@RequestMapping(value="orderDetails.html")
public ModelAndView getOrderDetails(HttpSession session){
	ModelAndView modelAndView = new ModelAndView();
	String user = (String) session.getAttribute("userId");
	List<OrderDetails> list = orderDetailsService.displayDetails(user);
	if("[]".equals(list.toString())){
		System.out.println("asd");
		modelAndView.setViewName("orderDelete");
		}
	//System.out.println(list);
	modelAndView.addObject("order",list);
	return modelAndView;
}
@RequestMapping("orderDelete.html")
public String orderDelete(){
	return "orderDelete";
}
@RequestMapping(value="orderRemove.html")
public ModelAndView removeItemFromOrders(@RequestParam("id") int id,HttpSession session){
	ModelAndView mav = new ModelAndView();
		orderDetailsService.deleteOrderItem(id);
		System.out.println("Item Removed Successfully from Orders...");
		String user = (String) session.getAttribute("userId");
		List<OrderDetails> list = orderDetailsService.displayDetails(user);
		System.out.println(list);
		mav.addObject("order",list);
		mav.setViewName("orderDetails");
		return mav;
}
	
}


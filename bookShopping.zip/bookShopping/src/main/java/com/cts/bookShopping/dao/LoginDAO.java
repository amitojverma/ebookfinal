package com.cts.bookShopping.dao;
import com.cts.bookShopping.bean.userRegistration;

public interface LoginDAO {
	public userRegistration authenticate(String emailId, String password);
	
}

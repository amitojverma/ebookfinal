package com.cts.bookShopping.dao;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.query.Query;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.cts.bookShopping.bean.AddToCart;
import com.cts.bookShopping.bean.Books;
import com.cts.bookShopping.bean.OrderDetails;

@Repository("orderDetailsDAO")
public class OrderDetailsDAOImpl implements OrderDetailsDAO{

	
	@Autowired
	@Qualifier("sessionFactory")
	SessionFactory sessionFactory;
	@Transactional
	public String insertDetails(OrderDetails books) {
		Session session = null;
		try {
		session = sessionFactory.getCurrentSession();
		session.save(books);
			return "true";
		}
		catch(Exception e)
		{
		      e.printStackTrace();
		}
		
		return "false";
		
	}
	@Transactional
	public List<OrderDetails> displayDetails(String emailId) {
Session session = null;
		try{
		String query= "from orderDetails where emailId = ?";
		Query<OrderDetails> query2=null;
		
		session = sessionFactory.getCurrentSession();
		query2=session.createQuery(query);
		query2.setParameter(0, emailId);
		
		List<OrderDetails> books = query2.getResultList();
		if(books==null)
			return null;
		else
			return books;
		}
	 catch (Exception e) {
		e.printStackTrace();
	}
		return null;
	}
	@Transactional
	public String deleteOrderItem(int id) {
		// TODO Auto-generated method stub
		Session session = null;
		String query= "from orderDetails where orderId = ?";
		Query<OrderDetails> query2=null;
		try {
			session = sessionFactory.getCurrentSession();
			query2=session.createQuery(query);
			query2.setParameter(0, id);
			OrderDetails product = query2.getSingleResult();
			session.delete(product);
				return "true";
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		return null;
	}
	
}


